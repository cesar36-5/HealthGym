﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class EntAlergia
    {
        public int IdAlergia { get; set; }
        public string Nombre { get; set; }
    }
}
